#!/data/data/com.termux/files/usr/bin/bash

clear

###################################################
# CTRL C
###################################################
trap ctrl_c INT
ctrl_c() {
clear
echo -e $blue"[#]> (Ctrl + C ) Detected, Trying To Exit ...$nc "
sleep 1
echo ""
echo -e $red"[#]> Terima kasih sudah make tools saya ...$nc "
sleep 1
echo ""
echo -e $white"[#]> Solo Player No TEAM !!! ...$nc "
sleep 0.5
exit
}
#colors
blue='\e[1;34m'
cyan='\e[0;36m'
green='\e[0;34m'
okegreen='\033[92m'
lightgreen='\e[1;32m'
grey="\033[0;37m"
purple="\033[0;35m"
yellow="\033[1;33m"
Purple="\033[0;35m"
Cafe="\033[0;33m"
Fiuscha="\033[0;35m"
lightcyan='\e[96m'
white='\e[1;37m'
nc="\e[0m"
red='\e[1;31m'
yellow='\e[1;33m'
#IP
DEFAULT_ROUTE=$(ip route show default | awk '/default/ {print $3}')
MYIP=$(ip route show | awk '(NR == 2) {print $9}')

clear
echo ""
                                             figlet                     DDOS-ATTACK                   | lolcat -a -d 5
echo ""
echo -e "           Gateway:\033[32m$DEFAULT_ROUTE |$white My-Ip:$red$MYIP"
echo ""
echo -e $red"              NOTE$white : Tools DDOS Full Performance , Author By$blue XcybeR$nc"
echo -e $white"                           Jan Lupa Make Wifi Unlimited Biar Lebih JOSS!!!:v$nc"
    echo -e "$lightgreen"
    echo "   ~~~~~[+] MASUKAN TARGET [+]~~~~~ "
    echo ""
    read -p "   Target:~# " target
    echo -e "$blue"
    echo "   ~~~~~[+] MASUKAN PORT [+]~~~~~ "
    echo ""
    read -p "   Port:~# " port
    echo -e "$lightgreen"
    echo "   ~~~~~[+] MASUKAN JUMLAH SERANGAN [+]~~~~~ "
    echo ""
    read -p "   Threads:~# " attack
    echo -e "$nc"
clear
echo ""
echo -e $blue"   Waiting For$red launch attack . . . $nc"
sleep 2
cd lib
python lol.py $target $port $attack



